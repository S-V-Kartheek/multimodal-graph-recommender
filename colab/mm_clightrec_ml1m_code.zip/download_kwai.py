import gdown
import zipfile
import os

file_id = '1NoisyVDFWykTszSIbHdeoBrKn0t-D0ps'
output_zip = 'Data.zip'
target_dir = r'C:\code playground\MGRS_ClightRec\kwai'

print(f"Downloading Kwai dataset from Google Drive...")
gdown.download(id=file_id, output=output_zip, quiet=False)

print(f"Dataset downloaded. Extracting...")
os.makedirs(target_dir, exist_ok=True)

with zipfile.ZipFile(output_zip, 'r') as zip_ref:
    zip_ref.extractall(r'C:\code playground\MGRS_ClightRec')

print(f"Extraction complete.")
