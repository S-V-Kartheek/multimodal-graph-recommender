"""
patch_notebook.py
=================
Patches MM_CLightRec_AmazonBaby_v2_FIXED (3).ipynb to inject Early Feature
Fusion into the LightGCN class, matching the optimized ML-1M architecture.

Run from the project root:
    python patch_notebook.py

Produces: MM_CLightRec_AmazonBaby_v3_EarlyFusion.ipynb
"""

import json, copy, os

SRC  = r"MM_CLightRec_AmazonBaby_v2_FIXED (3).ipynb"
DEST = r"MM_CLightRec_AmazonBaby_v3_EarlyFusion.ipynb"

# ─────────────────────────────────────────────────────────────────────────────
# NEW SOURCE CODE BLOCKS — replaces specific cells in the notebook
# ─────────────────────────────────────────────────────────────────────────────

# CELL 7 — Full Model Architecture with Early Fusion
NEW_CELL7_SRC = r"""
# ═══════════════════════════════════════════════════
# CHANGE 1: LightGCN CF  ← FIXED: Early Feature Fusion
# ═══════════════════════════════════════════════════
class LightGCN(nn.Module):
    # LightGCN with Early Feature Fusion.
    # Key upgrade from v2:
    #   ID embeddings are AUGMENTED with projected multimodal features
    #   BEFORE graph propagation — critical on 99.88% sparse graphs.
    #   e_u^(0) = Embed(u) + W_u * feat_u
    #   e_i^(0) = Embed(i) + W_i * feat_i
    #   Then standard L-layer symmetric normalized propagation.
    def __init__(self, n_users, n_items, embed_dim=64, n_layers=3,
                 user_feat_dim=None, item_feat_dim=None):
        super().__init__()
        self.n_users  = n_users
        self.n_items  = n_items
        self.n_layers = n_layers
        self.user_emb = nn.Embedding(n_users, embed_dim)
        self.item_emb = nn.Embedding(n_items, embed_dim)
        nn.init.xavier_normal_(self.user_emb.weight)
        nn.init.xavier_normal_(self.item_emb.weight)

        # ✅ Early Fusion projection layers
        self.user_feat_proj = nn.Linear(user_feat_dim, embed_dim) if user_feat_dim else None
        self.item_feat_proj = nn.Linear(item_feat_dim, embed_dim) if item_feat_dim else None

    def forward(self, edge_index, user_features=None, item_features=None):
        # Fuse ID embeddings with projected features
        e_u = self.user_emb.weight
        e_i = self.item_emb.weight
        if user_features is not None and self.user_feat_proj is not None:
            e_u = e_u + self.user_feat_proj(user_features)
        if item_features is not None and self.item_feat_proj is not None:
            e_i = e_i + self.item_feat_proj(item_features)

        all_emb = torch.cat([e_u, e_i], dim=0)
        embs    = [all_emb]
        row, col = edge_index
        n        = all_emb.size(0)
        deg      = torch.zeros(n, device=all_emb.device)
        deg.scatter_add_(0, row, torch.ones(row.size(0), device=all_emb.device))
        deg_inv_sqrt = (deg + 1e-8).pow(-0.5)
        norm = deg_inv_sqrt[row] * deg_inv_sqrt[col]
        for _ in range(self.n_layers):
            msg = norm.unsqueeze(1) * all_emb[col]
            agg = torch.zeros_like(all_emb)
            agg.scatter_add_(0, row.unsqueeze(1).expand_as(msg), msg)
            all_emb = agg
            embs.append(all_emb)
        final = torch.stack(embs, dim=1).mean(dim=1)
        return final[:self.n_users], final[self.n_users:]


# ═══════════════════════════════════════════════════
# CHANGE 2: Modality-Specific LightGCN (3 channels)
# ═══════════════════════════════════════════════════
class ModalityLightGCN(nn.Module):
    def __init__(self, input_dim, output_dim=64, n_layers=2):
        super().__init__()
        self.proj     = nn.Linear(input_dim, output_dim)
        self.n_layers = n_layers

    def forward(self, x, edge_index):
        x    = F.relu(self.proj(x))
        embs = [x]
        if edge_index is not None and edge_index.size(1) > 0:
            row, col = edge_index
            n   = x.size(0)
            deg = torch.zeros(n, device=x.device)
            deg.scatter_add_(0, row, torch.ones(row.size(0), device=x.device))
            deg_inv_sqrt = (deg + 1e-8).pow(-0.5)
            norm = deg_inv_sqrt[row] * deg_inv_sqrt[col]
            for _ in range(self.n_layers):
                msg = norm.unsqueeze(1) * x[col]
                agg = torch.zeros_like(x)
                agg.scatter_add_(0, row.unsqueeze(1).expand_as(msg), msg)
                x = agg
                embs.append(x)
        return torch.stack(embs, dim=1).mean(dim=1)


# ═══════════════════════════════════════════════════
# CHANGE 3: L1 Projection Heads with BatchNorm
# ═══════════════════════════════════════════════════
class ModalityProjectionHead(nn.Module):
    def __init__(self, input_dim, hidden_dim=256, output_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, output_dim)
        )
    def forward(self, x):
        return F.normalize(self.net(x), dim=-1)


def info_nce_loss(z_a, z_b, temperature=0.2):
    N      = z_a.size(0)
    sim    = torch.matmul(z_a, z_b.T) / temperature
    labels = torch.arange(N, device=z_a.device)
    return (F.cross_entropy(sim, labels) +
            F.cross_entropy(sim.T, labels)) / 2.0


# ═══════════════════════════════════════════════════
# COMPLETE MODEL — Early Fusion + 3 modalities
# ═══════════════════════════════════════════════════
class MM_CLightRec(nn.Module):
    def __init__(self, n_users, n_items, config, modality_dims,
                 user_feat_dim=None, item_feat_dim=None):
        super().__init__()
        d = config['embed_dim']
        c = config['contrastive_dim']
        self.config  = config
        self.n_users = n_users
        self.n_items = n_items

        # CF: LightGCN with Early Fusion
        self.lightgcn = LightGCN(
            n_users, n_items, d, config['n_layers'],
            user_feat_dim=user_feat_dim,
            item_feat_dim=item_feat_dim,
        )

        # CBF: 3 modality channels (text, image, meta)
        self.text_lgcn  = ModalityLightGCN(modality_dims['text'],  d)
        self.image_lgcn = ModalityLightGCN(modality_dims['image'], d)
        self.meta_lgcn  = ModalityLightGCN(modality_dims['meta'],  d)

        # Adaptive fusion for 3 channels
        self.fusion_w = nn.Linear(d * 3, 3)

        # L1 projection heads
        self.proj_text  = ModalityProjectionHead(modality_dims['text'],  256, c)
        self.proj_image = ModalityProjectionHead(modality_dims['image'], 256, c)

        # Cross-Attention
        self.attn_scale = d ** 0.5
        self.W_Q = nn.Linear(d, d)
        self.W_K = nn.Linear(d, d)
        self.W_V = nn.Linear(d, d)

        # VGAE with proper initialization
        self.vgae_mu     = nn.Linear(d, 32)
        self.vgae_logvar = nn.Linear(d, 32)
        self.vgae_dec    = nn.Linear(32, d)
        nn.init.normal_(self.vgae_logvar.weight, std=0.01)
        nn.init.constant_(self.vgae_logvar.bias, -2.0)

        self.cluster_built = False

    def build_cluster_graph(self, user_features, item_features):
        threshold = self.config['cluster_threshold']
        print(f'[MODEL] Building cluster graph (threshold={threshold})...')
        X_U  = user_features.detach().cpu().numpy()
        X_I  = item_features.detach().cpu().numpy()
        n_uc = self.config['n_clusters_u']
        n_ic = self.config['n_clusters_i']

        km_u = KMeans(n_clusters=n_uc, random_state=42, n_init=10)
        km_i = KMeans(n_clusters=n_ic, random_state=42, n_init=10)
        km_u.fit(X_U)
        km_i.fit(X_I)

        u_cent = km_u.cluster_centers_
        i_cent = km_i.cluster_centers_
        sim    = cosine_similarity(u_cent, i_cent)
        u_idx, i_idx = np.where(sim > threshold)

        if len(u_idx) == 0:
            flat  = sim.flatten()
            top_k = np.argsort(flat)[-n_uc*3:]
            u_idx = top_k // n_ic
            i_idx = top_k % n_ic

        i_off = i_idx + n_uc
        row   = np.concatenate([u_idx, i_off])
        col   = np.concatenate([i_off, u_idx])
        self.cluster_edge_index = torch.LongTensor(np.stack([row, col]))
        self.n_cluster_nodes    = n_uc + n_ic
        self.user_labels = torch.LongTensor(km_u.labels_)
        self.item_labels = torch.LongTensor(km_i.labels_)
        self.n_uc = n_uc
        self.n_ic = n_ic
        self.cluster_built = True
        print(f'[MODEL] Cluster graph: {len(u_idx)} edges, {n_uc}u + {n_ic}i clusters ✅')

    def forward(self, edge_index, modality_features,
                user_features=None, item_features=None):
        device = next(self.parameters()).device
        ei     = edge_index.to(device)

        f_text  = modality_features['text'].to(device)
        f_image = modality_features['image'].to(device)
        f_meta  = modality_features['meta'].to(device)

        # Step 1: LightGCN CF — NOW with Early Feature Fusion
        uf = user_features.to(device) if user_features is not None else None
        if_= item_features.to(device) if item_features is not None else None
        H_U, H_I = self.lightgcn(ei, uf, if_)

        # Step 2: MM-LightGCN CBF (3 channels)
        if self.cluster_built:
            c_ei     = self.cluster_edge_index.to(device)
            i_labels = self.item_labels.to(device)
            u_labels = self.user_labels.to(device)

            def cluster_feat(feat, labels, n_c):
                out = torch.zeros(n_c, feat.size(-1), device=device)
                out.scatter_add_(0, labels.unsqueeze(1).expand_as(feat), feat)
                cnt = torch.bincount(labels, minlength=n_c).float().unsqueeze(1).clamp(min=1)
                return out / cnt

            def pad_u(dim):
                return torch.zeros(self.n_uc, dim, device=device)

            t_c  = cluster_feat(f_text,  i_labels, self.n_ic)
            im_c = cluster_feat(f_image, i_labels, self.n_ic)
            m_c  = cluster_feat(f_meta,  i_labels, self.n_ic)

            t_all  = torch.cat([pad_u(f_text.size(-1)),  t_c],  dim=0)
            im_all = torch.cat([pad_u(f_image.size(-1)), im_c], dim=0)
            m_all  = torch.cat([pad_u(f_meta.size(-1)),  m_c],  dim=0)

            e_t  = self.text_lgcn( t_all,  c_ei)
            e_im = self.image_lgcn(im_all, c_ei)
            e_m  = self.meta_lgcn( m_all,  c_ei)

            combined  = torch.cat([e_t, e_im, e_m], dim=-1)
            w         = F.softmax(self.fusion_w(combined), dim=-1)
            H_cluster = w[:,0:1]*e_t + w[:,1:2]*e_im + w[:,2:3]*e_m

            H_UI_items = H_cluster[self.n_uc:][i_labels]
            H_UI_users = H_cluster[:self.n_uc][u_labels]
        else:
            H_UI_items = H_I
            H_UI_users = H_U

        # Step 3: Cross-Attention
        Q      = self.W_Q(H_U)
        K      = self.W_K(H_I)
        V      = self.W_V(H_UI_items)
        scores = torch.matmul(Q, K.T) / self.attn_scale
        attn   = F.softmax(scores, dim=-1)
        Z      = torch.matmul(attn, V)

        # Step 4: VGAE
        mu     = self.vgae_mu(Z)
        logvar = self.vgae_logvar(Z).clamp(-4, 4)
        std    = torch.exp(0.5 * logvar)
        z_vgae = mu + torch.randn_like(std) * std
        Z_dec  = self.vgae_dec(z_vgae)

        return {
            'H_U': H_U, 'H_I': H_I,
            'H_UI_users': H_UI_users,
            'H_UI_items': H_UI_items,
            'Z': Z, 'Z_dec': Z_dec,
            'mu': mu, 'logvar': logvar,
            'f_text':  f_text,
            'f_image': f_image,
        }


print('Model defined with v3 Early Fusion ✅')
print('  Fix 1: VGAE logvar bias=-2.0, clamp(-4,4)')
print('  Fix 2: BatchNorm in projection heads')
print('  Fix 3: Video channel removed (no real video in Baby)')
print('  Fix 4: 3-channel adaptive fusion')
print('  ✅ NEW: LightGCN fuses user/item features before propagation (Early Fusion)')
""".lstrip()

# CELL 10 — Model Initialization with Early Fusion dims
NEW_CELL10_SRC = r"""
# ✅ v3 FRESH MODEL — Early Fusion enabled

# Build user & item feature matrices (concatenation of text + image)
# These are used by LightGCN's Early Fusion projection layers
user_feat_np = data['user_features'].numpy()   # (n_users, text_dim+image_dim)
item_feat_np = data['item_features'].numpy()   # (n_items, text_dim+image_dim)
USER_FEAT_DIM = user_feat_np.shape[1]
ITEM_FEAT_DIM = item_feat_np.shape[1]

# Move to device tensors
user_features_t = data['user_features'].to(DEVICE)
item_features_t = data['item_features'].to(DEVICE)

modality_dims = {
    'text':  data['modality_features']['text'].shape[1],
    'image': data['modality_features']['image'].shape[1],
    'meta':  data['modality_features']['meta'].shape[1],
}
print(f'Modality dims:   {modality_dims}')
print(f'User feat dim:   {USER_FEAT_DIM}  (for Early Fusion)')
print(f'Item feat dim:   {ITEM_FEAT_DIM}  (for Early Fusion)')

model = MM_CLightRec(
    n_users=data['n_users'],
    n_items=data['n_items'],
    config=CONFIG,
    modality_dims=modality_dims,
    user_feat_dim=USER_FEAT_DIM,
    item_feat_dim=ITEM_FEAT_DIM,
).to(DEVICE)

# Verify KL fix
logvar_bias = model.vgae_logvar.bias[:3]
print(f'logvar bias: {logvar_bias.detach()}')
assert (logvar_bias < -1.5).all(), 'KL fix not working!'
print('KL fix verified ✅')

optimizer = torch.optim.Adam(
    model.parameters(),
    lr=CONFIG['lr'],
    weight_decay=CONFIG['weight_decay']
)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
    optimizer,
    T_max=CONFIG['n_epochs'],
    eta_min=CONFIG['lr_min']
)

# PCA + K-means ONCE on actual feature matrices (not huge raw dims)
from sklearn.decomposition import PCA
print('\n[INIT] PCA + K-means...')
t0   = time.time()
pca_u = PCA(n_components=64, random_state=42)
pca_i = PCA(n_components=64, random_state=42)
u_r   = pca_u.fit_transform(user_feat_np)
i_r   = pca_i.fit_transform(item_feat_np)
print(f'[INIT] PCA done: {time.time()-t0:.1f}s')
model.build_cluster_graph(
    torch.FloatTensor(u_r).to(DEVICE),
    torch.FloatTensor(i_r).to(DEVICE)
)

history = {
    'total':[],'BPR':[],'L1':[],
    'L2':[],'L3':[],'KL':[]
}

START_EPOCH = 0
best_ndcg   = 0.0
no_improve  = 0

print('\n✅ v3 Model ready — Early Fusion active, fresh start from epoch 0')
print('='*70)
""".lstrip()

# CELL 11 — Evaluation with user/item features passed in
NEW_CELL11_SRC = r"""
def compute_ndcg(pred_items, true_items, k):
    dcg, idcg = 0.0, 0.0
    for rank, item in enumerate(pred_items[:k]):
        if item in true_items:
            dcg += 1.0 / np.log2(rank + 2)
    for rank in range(min(len(true_items), k)):
        idcg += 1.0 / np.log2(rank + 2)
    return dcg / idcg if idcg > 0 else 0.0


@torch.no_grad()
def evaluate(model, data, config, split='test'):
    model.eval()
    k       = config['K']
    n_users = data['n_users']
    n_items = data['n_items']
    device  = config['device']

    mod_gpu = {mk: mv.to(device) for mk, mv in data['modality_features'].items()}

    # ✅ Pass user/item features for Early Fusion
    uf = data['user_features'].to(device)
    if_ = data['item_features'].to(device)
    outputs = model(data['edge_index'], mod_gpu,
                    user_features=uf, item_features=if_)
    H_U = outputs['H_U']
    H_I = outputs['H_I']

    scores = torch.matmul(H_U, H_I.T)

    # Mask training items
    for u, items in data['train_user_items'].items():
        if items:
            scores[u, items] = -1e9

    _, top_k = scores.topk(k, dim=-1)
    top_k    = top_k.cpu().numpy()

    eval_items = data['test_user_items'] if split == 'test' else data['val_user_items']

    prec, rec, ndcg, f1, acc = [], [], [], [], []
    for u in range(n_users):
        true = set(eval_items.get(u, []))
        if not true: continue
        pred = list(top_k[u])
        hits = len(set(pred) & true)
        p = hits / k
        r = hits / len(true)
        n = compute_ndcg(pred, true, k)
        f = 2*p*r/(p+r) if (p+r) > 0 else 0.0
        prec.append(p); rec.append(r)
        ndcg.append(n); f1.append(f); acc.append(p)

    # RMSE
    rmse = 0.0
    if data.get('all_ratings') is not None:
        try:
            H_U_c = H_U.cpu()
            H_I_c = H_I.cpu()
            preds, tgts = [], []
            for row in data['all_ratings'][:5000]:
                u_i = min(int(row[0]), n_users-1)
                i_i = min(int(row[1]), n_items-1)
                r   = float(row[2])
                s   = (H_U_c[u_i] * H_I_c[i_i]).sum().item()
                preds.append(1 + 4*torch.sigmoid(torch.tensor(s)).item())
                tgts.append(r)
            rmse = np.sqrt(np.mean((np.array(preds) - np.array(tgts))**2))
        except:
            rmse = 0.0

    return {
        'Precision@K': np.mean(prec) if prec else 0.0,
        'Recall@K':    np.mean(rec)  if rec  else 0.0,
        'NDCG@K':      np.mean(ndcg) if ndcg else 0.0,
        'F1-Score@K':  np.mean(f1)   if f1   else 0.0,
        'Accuracy@K':  np.mean(acc)  if acc  else 0.0,
        'RMSE':        rmse
    }


@torch.no_grad()
def evaluate_cold_start(model, data, config, split='test'):
    model.eval()
    top_k_count = config['K']
    n_users = data['n_users']
    device  = config['device']

    cold_users = [
        u for u in range(n_users)
        if len(data['train_user_items'].get(u, [])) <= config['keep_k']
    ]
    if not cold_users:
        all_u  = list(data['train_user_items'].keys())
        n_cold = max(1, int(len(all_u)*0.2))
        cold_users = all_u[:n_cold]

    mod_gpu = {mk: mv.to(device) for mk, mv in data['modality_features'].items()}
    uf  = data['user_features'].to(device)
    if_ = data['item_features'].to(device)
    outputs = model(data['edge_index'].to(device), mod_gpu,
                    user_features=uf, item_features=if_)
    H_U = outputs['H_U']
    H_I = outputs['H_I']
    scores = torch.matmul(H_U, H_I.T)
    for u, items in data['train_user_items'].items():
        if items: scores[u, items] = -1e9

    cold_t  = torch.tensor(cold_users, dtype=torch.long, device=device)
    _, top_k = scores[cold_t].topk(top_k_count, dim=-1)
    top_k   = top_k.cpu().numpy()

    eval_items = data['test_user_items'] if split=='test' else data['val_user_items']
    hits, ndcgs, recalls = [], [], []
    for i, u in enumerate(cold_users):
        true = set(eval_items.get(u, []))
        if not true: continue
        pred = list(top_k[i])
        h    = len(set(pred) & true)
        hits.append(1.0 if h > 0 else 0.0)
        recalls.append(h / len(true))
        ndcgs.append(compute_ndcg(pred, true, top_k_count))

    return {
        'ColdStart-Hit@K':    np.mean(hits)    if hits    else 0.0,
        'ColdStart-NDCG@K':   np.mean(ndcgs)   if ndcgs   else 0.0,
        'ColdStart-Recall@K': np.mean(recalls) if recalls else 0.0,
        'n_cold_users':       len(cold_users)
    }


print('Evaluation functions defined ✅')
print(f'  Users: {data["n_users"]:,} | Items: {data["n_items"]:,} | K={CONFIG["K"]}')
print('  ✅ NEW: Evaluation passes user/item features for Early Fusion inference')
""".lstrip()

# CELL 13 — Training loop with user/item features in forward call
NEW_CELL13_SRC = r"""
print('=' * 70)
print('MM-CLightRec v3.0 — Amazon Baby — Early Fusion + ALL FIXES')
print('=' * 70)
print(f'λ1={CONFIG["lambda1"]} λ2={CONFIG["lambda2"]} λ3={CONFIG["lambda3"]} λ4={CONFIG["lambda4"]}')
print(f'LR: {CONFIG["lr"]} → cosine → {CONFIG["lr_min"]}')
print(f'✅ NEW: LightGCN fuses {USER_FEAT_DIM}D user + {ITEM_FEAT_DIM}D item features')
print('=' * 70)

edge_index_gpu = data['edge_index'].to(DEVICE)

for epoch in range(START_EPOCH, CONFIG['n_epochs']):
    model.train()
    t0 = time.time()
    loss_accum = dict(total=0, BPR=0, L1=0, L2=0, L3=0, KL=0)
    n_batches  = 0

    for batch in train_loader:
        batch = batch.to(DEVICE)
        u_ids, p_ids, n_ids = batch[:,0], batch[:,1], batch[:,2]

        mod_gpu = {mk: mv.to(DEVICE) for mk, mv in data['modality_features'].items()}

        # ✅ Forward with Early Fusion features
        outputs = model(
            edge_index_gpu, mod_gpu,
            user_features=user_features_t,
            item_features=item_features_t,
        )

        L_total, losses = compute_total_loss(
            outputs, model, u_ids, p_ids, n_ids, CONFIG, edge_index_gpu
        )

        optimizer.zero_grad()
        L_total.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        for k, v in losses.items():
            loss_accum[k] += v
        n_batches += 1

    scheduler.step()

    for k in loss_accum:
        loss_accum[k] /= max(n_batches, 1)
    for k in history:
        history[k].append(loss_accum[k])

    elapsed = time.time() - t0
    ep_str  = (f"Ep {epoch+1:4d}/{CONFIG['n_epochs']} | "
               f"Loss:{loss_accum['total']:.4f} | "
               f"BPR:{loss_accum['BPR']:.4f} | "
               f"L1:{loss_accum['L1']:.4f} | "
               f"L2:{loss_accum['L2']:.4f} | "
               f"L3:{loss_accum['L3']:.4f} | "
               f"KL:{loss_accum['KL']:.4f} | "
               f"lr:{scheduler.get_last_lr()[0]:.2e} | {elapsed:.0f}s")
    print(ep_str)

    if (epoch + 1) % CONFIG['eval_every'] == 0:
        val_m    = evaluate(model, data, CONFIG, split='val')
        cold_m   = evaluate_cold_start(model, data, CONFIG, split='val')
        val_ndcg = val_m['NDCG@K']
        print(f"  [VAL]  Prec:{val_m['Precision@K']:.4f} | "
              f"Rec:{val_m['Recall@K']:.4f} | "
              f"NDCG:{val_ndcg:.4f} | "
              f"F1:{val_m['F1-Score@K']:.4f} | "
              f"RMSE:{val_m['RMSE']:.4f}")
        print(f"  [COLD] Hit:{cold_m['ColdStart-Hit@K']:.4f} | "
              f"NDCG:{cold_m['ColdStart-NDCG@K']:.4f} | "
              f"Rec:{cold_m['ColdStart-Recall@K']:.4f}")

        if val_ndcg > best_ndcg:
            best_ndcg = val_ndcg
            no_improve = 0
            print(f"  [BEST] NDCG:{best_ndcg:.4f} ✅")
            ckpt_path = f"{CONFIG['checkpoint_dir']}/epoch_{epoch+1}_v3.pt"
            save_checkpoint(model, optimizer, scheduler, epoch+1, val_m, history, ckpt_path)
        else:
            no_improve += 1
            if no_improve >= CONFIG['patience'] // CONFIG['eval_every']:
                print(f"[EARLY STOP] No improvement for {CONFIG['patience']} epochs.")
                break

    if (epoch + 1) % CONFIG['save_every'] == 0:
        ckpt_path = f"{CONFIG['checkpoint_dir']}/epoch_{epoch+1}_v3.pt"
        save_checkpoint(model, optimizer, scheduler, epoch+1, {}, history, ckpt_path)

print('\n✅ Training complete')

# ── Final Test Evaluation ──────────────────────────────────────────────────
print('=' * 70)
print('FINAL EVALUATION ON TEST SET')
print('=' * 70)
test_m  = evaluate(model, data, CONFIG, split='test')
cold_m  = evaluate_cold_start(model, data, CONFIG, split='test')
print(f"{'Metric':<25} {'Value':<10}")
print('-' * 35)
for metric, value in test_m.items():
    print(f'{metric:<25} {value:<10.4f}')
print()
for metric, value in cold_m.items():
    if isinstance(value, float):
        print(f'{metric:<25} {value:<10.4f}')

# ── Plots ──────────────────────────────────────────────────────────────────
import matplotlib.pyplot as plt

fig, axes = plt.subplots(1, 3, figsize=(16, 4))
axes[0].plot(history['total'], label='Total Loss')
axes[0].plot(history['BPR'],   label='BPR')
axes[0].set_title('Training Loss'); axes[0].legend()

axes[1].plot(history['L1'], label='L1 Inter-Modal')
axes[1].plot(history['L2'], label='L2 Structural')
axes[1].plot(history['L3'], label='L3 Cold-Start')
axes[1].set_title('Contrastive Losses'); axes[1].legend()

metrics_val = [test_m['Precision@K'], test_m['Recall@K'],
               test_m['NDCG@K'],      test_m['F1-Score@K']]
axes[2].bar(['P@10','R@10','NDCG@10','F1@10'], metrics_val, color='steelblue')
axes[2].set_title('Final Test Metrics'); axes[2].set_ylim(0, max(metrics_val)*1.3)
for i, v in enumerate(metrics_val):
    axes[2].text(i, v + 0.001, f'{v:.4f}', ha='center', fontsize=9)

plt.tight_layout()
plot_path = f"{CONFIG['results_dir']}/plots/training_v3.png"
plt.savefig(plot_path, dpi=120)
plt.show()
print(f'[PLOT SAVED] {plot_path}')
""".lstrip()


# ─────────────────────────────────────────────────────────────────────────────
# Helper: convert Python source string to notebook cell line list
# ─────────────────────────────────────────────────────────────────────────────
def to_cell_lines(src: str):
    lines = src.split('\n')
    return [line + '\n' for line in lines[:-1]] + ([lines[-1]] if lines[-1] else [])


# ─────────────────────────────────────────────────────────────────────────────
# Main patching logic
# ─────────────────────────────────────────────────────────────────────────────
def patch():
    if not os.path.exists(SRC):
        print(f"[ERROR] Source notebook not found: {SRC}")
        print("  Make sure you run this script from the MGRS_ClightRec directory.")
        return

    with open(SRC, 'r', encoding='utf-8') as f:
        nb = json.load(f)

    cells = nb['cells']

    # Map cell header → target new source
    CELL_PATCHES = {
        'CELL 7': NEW_CELL7_SRC,
        'CELL 10': NEW_CELL10_SRC,
        'CELL 11': NEW_CELL11_SRC,
        'CELL 13': NEW_CELL13_SRC,
    }

    patched = set()

    for idx, cell in enumerate(cells):
        # A markdown cell signals the next code cell's identity
        if cell['cell_type'] == 'markdown':
            src_text = ''.join(cell['source'])
            for label in CELL_PATCHES:
                if label in src_text and label not in patched:
                    # Find the next code cell after this markdown
                    for j in range(idx + 1, len(cells)):
                        if cells[j]['cell_type'] == 'code':
                            old_src = ''.join(cells[j]['source'])
                            new_src  = CELL_PATCHES[label]
                            cells[j]['source']   = to_cell_lines(new_src)
                            cells[j]['outputs']  = []
                            cells[j]['execution_count'] = None
                            patched.add(label)
                            print(f"  ✅ Patched {label} (cell index {j})")
                            break

    # Update title markdown cell
    for cell in cells:
        if cell['cell_type'] == 'markdown':
            joined = ''.join(cell['source'])
            if 'MM-CLightRec v2.0' in joined:
                cell['source'] = [
                    '# MM-CLightRec **v3.0** — Amazon Baby Dataset\n',
                    '## ✅ Early Fusion + All Previous Bug Fixes — Fresh Run Only\n',
                    '\n',
                    '**Key upgrade over v2:** LightGCN now fuses rich text/image features \n',
                    'directly into graph embeddings **before** propagation (Early Fusion). \n',
                    'This is critical for 99.88% sparse graphs where ID-only signals collapse.\n',
                    '\n',
                    '**Expected NDCG target: 0.030 → 0.055–0.085**',
                ]
                print("  ✅ Updated notebook title to v3.0")
                break

    if len(patched) < len(CELL_PATCHES):
        missing = set(CELL_PATCHES) - patched
        print(f"\n[WARNING] Could not find cells for: {missing}")
        print("  The notebook structure may have shifted. Saving anyway.")

    with open(DEST, 'w', encoding='utf-8') as f:
        json.dump(nb, f, indent=1, ensure_ascii=False)

    print(f"\n[SUCCESS] Patched notebook saved to: {DEST}")
    print("  Upload this file to Google Colab to get your improved metrics!")


if __name__ == '__main__':
    print(f"Patching: {SRC}")
    print(f"Output:   {DEST}\n")
    patch()
