"""
Training module for MM-CLightRec model.

Unified hierarchical loss (Change 6):
    L_total = L_BPR + lambda1*L_inter + lambda2*L_struct + lambda3*L_cold + lambda4*L_KL

Where:
- L_BPR:   Bayesian Personalized Ranking loss (ranking supervision)
- L_inter: Inter-modal contrastive loss L1 (modality alignment)  
- L_struct: Structural graph contrastive loss L2 (sparsity compensation)
- L_cold:  Cluster-aware cold-start contrastive loss L3 (journal only)
- L_KL:    VGAE KL divergence (regularization)
"""

import os
import time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from tqdm import tqdm

from models.mm_clightrec import MM_CLightRec
from models.contrastive_losses import simulate_cold_start, cold_start_contrastive_loss
from models.content_filtering import cluster_features
from evaluate import evaluate_model, evaluate_model_subset, evaluate_link_prediction
from visualize import (plot_training_loss, plot_metrics_bar, plot_metrics_over_epochs, 
                        plot_link_prediction_metrics, plot_loss_components)


def bpr_loss(pos_scores, neg_scores):
    """
    Bayesian Personalized Ranking loss.
    L_BPR = -Σ log σ(ŷ_ui - ŷ_uj)
    
    Directly optimizes the relative ranking of observed vs unobserved interactions.
    
    Args:
        pos_scores: Predicted scores for positive (observed) interactions
        neg_scores: Predicted scores for negative (unobserved) interactions
    
    Returns:
        loss: BPR loss scalar
    """
    return -torch.mean(F.logsigmoid(pos_scores - neg_scores))


def negative_sampling_bpr(user_idx, item_idx, n_items, n_neg=1, popularity=None):
    """
    Generate BPR training triplets: (user, positive_item, negative_item).
    If popularity is provided, 50% of negatives are sampled from the top 20% most popular items
    to create "hard" negatives for better ranking precision.
    """
    n_pos = len(user_idx)
    
    # Build user->set of positive items to avoid false negatives
    user_pos = {}
    for u, i in zip(user_idx, item_idx):
        user_pos.setdefault(int(u), set()).add(int(i))

    if popularity is not None:
        # Threshold for top 20% items
        thresh = np.percentile(popularity, 80)
        popular_items = np.where(popularity >= thresh)[0]
        
        # Sample half uniform, half popular
        uniform_neg = np.random.randint(0, n_items, size=n_pos * n_neg)
        if len(popular_items) > 0:
            hard_neg = np.random.choice(popular_items, size=n_pos * n_neg)
            mask = np.random.rand(n_pos * n_neg) > 0.5
            neg_items = np.where(mask, hard_neg, uniform_neg)
        else:
            neg_items = uniform_neg
    else:
        neg_items = np.random.randint(0, n_items, size=n_pos * n_neg)
    
    users = np.repeat(user_idx, n_neg)
    pos_items = np.repeat(item_idx, n_neg)

    # Fix false negatives by resampling a few times
    for t in range(5):
        bad = np.fromiter(
            (int(neg_items[j]) in user_pos.get(int(users[j]), set()) for j in range(len(neg_items))),
            dtype=bool,
            count=len(neg_items),
        )
        if not bad.any():
            break
        neg_items[bad] = np.random.randint(0, n_items, size=int(bad.sum()))
    
    return users, pos_items, neg_items


def train_mm_clightrec(data, config=None):
    """
    Train the MM-CLightRec model.
    
    Args:
        data: dict from data_loader containing all preprocessed data
        config: dict of hyperparameters
    
    Returns:
        model: trained model
        results: dict of training history and final metrics
    """
    if config is None:
        config = {}

    # Keep dataset name for checkpoints/logging
    config.setdefault("dataset", "ml1m")
    
    # Hyperparameters
    epochs = config.get('epochs', 100)
    lr = config.get('lr', 0.001)
    weight_decay = config.get('weight_decay', 1e-4)
    batch_size = config.get('batch_size', 4096)
    cf_embed_dim = config.get('cf_embed_dim', 32)
    cf_n_layers = config.get('cf_n_layers', 3)
    cbf_out_dim = config.get('cbf_out_dim', 32)
    cbf_n_layers = config.get('cbf_n_layers', 2)
    n_user_clusters = config.get('n_user_clusters', 20)
    n_item_clusters = config.get('n_item_clusters', 15)
    vgae_hidden_dim = config.get('vgae_hidden_dim', 100)
    vgae_latent_dim = config.get('vgae_latent_dim', 50)
    contrastive_proj_dim = config.get('contrastive_proj_dim', 64)
    temperature = config.get('temperature', 0.2)
    k = config.get('k', 10)
    eval_every = config.get('eval_every', 10)
    save_every = config.get('save_every', 5)
    patience = config.get('patience', 15)
    n_neg = config.get('n_neg', 1)
    include_cold_start = config.get('include_cold_start', False)
    
    # Loss weights (λ values)
    lambda_1 = config.get('lambda_1', 0.1)   # L_inter
    lambda_2 = config.get('lambda_2', 0.1)   # L_struct
    lambda_3 = config.get('lambda_3', 0.05)  # L_cold
    lambda_4 = config.get('lambda_4', 0.01)  # L_KL
    
    # Device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"[INFO] Using device: {device}")
    
    # Extract data
    user_features = data['user_features'].to(device)
    item_features = data['item_features'].to(device)
    edge_index = data['edge_index'].to(device)  # train edges only (no leakage)
    n_users = data['n_users']
    n_items = data['n_items']
    feature_dim = data['feature_dim']
    user_idx = data['user_idx']
    item_idx = data['item_idx']
    ratings = data['ratings']
    train_idx = data['train_idx']
    val_idx = data['val_idx']
    test_idx = data['test_idx']
    rating_matrix = data['rating_matrix']
    modality_dims = data['modality_dims']
    
    # Per-modality features
    user_modality_features = {
        name: feat.to(device) for name, feat in data['user_modality_features'].items()
    }
    item_modality_features = {
        name: feat.to(device) for name, feat in data['item_modality_features'].items()
    }
    
    print(f"[INFO] Feature dim: {feature_dim}, Users: {n_users}, Items: {n_items}")
    print(f"[INFO] Modality dims: {modality_dims}")
    
    # Initialize model
    model = MM_CLightRec(
        n_users=n_users,
        n_items=n_items,
        user_feature_dim=feature_dim,
        item_feature_dim=feature_dim,
        modality_dims=modality_dims,
        cf_embed_dim=cf_embed_dim,
        cf_n_layers=cf_n_layers,
        cbf_out_dim=cbf_out_dim,
        cbf_n_layers=cbf_n_layers,
        n_user_clusters=n_user_clusters,
        n_item_clusters=n_item_clusters,
        vgae_hidden_dim=vgae_hidden_dim,
        vgae_latent_dim=vgae_latent_dim,
        contrastive_proj_dim=contrastive_proj_dim,
        temperature=temperature,
        include_cold_start=include_cold_start
    ).to(device)
    
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"[INFO] Total parameters:     {total_params:,}")
    print(f"[INFO] Trainable parameters: {trainable_params:,}")
    print(f"[INFO] Loss weights: lambda1={lambda_1}, lambda2={lambda_2}, lambda3={lambda_3}, lambda4={lambda_4}")
    print(f"[INFO] Include cold-start (L3): {include_cold_start}")
    
    # Optimizer and Scheduler
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=lr/10)
    
    # KL Annealing (beta warmup)
    # Linearly increase beta from 0 to lambda_4 over first 20 epochs
    warmup_epochs = 20
    
    # Training history
    train_losses = []
    loss_components_history = {
        'L_BPR': [], 'L_inter': [], 'L_struct': [], 'L_KL': [], 'L_cold': [], 'L_total': []
    }
    epoch_metrics_history = {
        'Precision@K': [], 'Recall@K': [], 'NDCG@K': [],
        'F1-Score@K': [], 'Accuracy@K': [], 'RMSE': []
    }
    cold_start_metrics_history = {
        'ColdStart-Hit@K': [], 'ColdStart-NDCG@K': [], 'ColdStart-Recall@K': []
    }
    
    # Training mask for evaluation (warm users only)
    train_mask = np.zeros((n_users, n_items), dtype=bool)
    for idx in train_idx:
        u, i = user_idx[idx], item_idx[idx]
        train_mask[u, i] = True
    
    # Training loop
    # Calculate item popularity for hard negative sampling
    item_counts = np.bincount(item_idx[train_idx], minlength=n_items)
    # Build cluster similarity graph ONCE before the logic
    print("[INIT] Building cluster similarity graph (runs once)...")
    cluster_edge_index, user_labels, item_labels = model.cbf_module.build_cluster_graph(
        user_features.cpu(), item_features.cpu()
    )
    print(f"[INIT] Cluster graph ready. Starting training for {epochs} epochs...")
    best_f1 = 0.0
    best_model_state = None
    best_val_ndcg = -1.0
    bad_eval_count = 0
    start_epoch = 1
    
    import os
    resume_path = config.get('resume', None)
    
    # ── AUTO-RESUME SAFEGUARD ──────────────────────────────────────────────────
    # If the user restarts Colab, automatically pick up the best model from Drive
    # so we don't accidentally overwrite 5 hours of training with Epoch 1.
    if resume_path is None or resume_path.lower() == 'auto':
        auto_path = "results/best_model.pth"
        if os.path.exists(auto_path):
            resume_path = auto_path
            print(f"[INFO] 🛡️ AUTO-RESUME TRIGGERED: Found existing checkpoint.")
    # ───────────────────────────────────────────────────────────────────────────

    if resume_path and os.path.exists(resume_path):
        print(f"[INFO] Resuming from checkpoint: {resume_path}")
        checkpoint = torch.load(resume_path, map_location=device)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        start_epoch = checkpoint['epoch'] + 1
        best_val_ndcg = checkpoint.get('best_val_ndcg', -1.0)
        
        # Reload history
        if 'train_losses' in checkpoint:
            train_losses = checkpoint['train_losses']
        if 'loss_components_history' in checkpoint:
            loss_components_history = checkpoint['loss_components_history']
        if 'epoch_metrics_history' in checkpoint:
            epoch_metrics_history = checkpoint['epoch_metrics_history']
        if 'cold_start_metrics_history' in checkpoint:
            cold_start_metrics_history = checkpoint['cold_start_metrics_history']
        if 'best_model_state' in checkpoint:
            best_model_state = checkpoint['best_model_state']
            
        print(f"[INFO] Resumed at epoch {start_epoch} with best val NDCG: {best_val_ndcg:.4f}")

    
    for epoch in range(start_epoch, epochs + 1):
        model.train()
        epoch_start = time.time()
        
        # Get training interactions
        train_users = user_idx[train_idx]
        train_items = item_idx[train_idx]
        
        # BPR negative sampling with popularity bias (Hard Negatives)
        bpr_users, bpr_pos_items, bpr_neg_items = negative_sampling_bpr(
            train_users, train_items, n_items, n_neg=n_neg, popularity=item_counts
        )
        
        # Shuffle
        perm = np.random.permutation(len(bpr_users))
        bpr_users = bpr_users[perm]
        bpr_pos_items = bpr_pos_items[perm]
        bpr_neg_items = bpr_neg_items[perm]
        
        # Epoch accumulators
        epoch_loss_bpr = 0.0
        epoch_loss_kl = 0.0
        epoch_loss_inter = 0.0
        epoch_loss_struct = 0.0
        epoch_loss_cold = 0.0
        n_batches = int(np.ceil(len(bpr_users) / batch_size)) if batch_size > 0 else 1

        # ---------------------------------------------------------------------
        # EXPENSIVE GRAPH COMPUTATIONS (run once per epoch, not per batch)
        # ---------------------------------------------------------------------
        # Compute CF + CBF + Attention once, then VGAE encode once.
        H_U, H_I = model.cf_module(user_features, item_features, edge_index)
        _, H_UI_users, H_UI_items = model.cbf_module(
            user_features, item_features,
            user_modality_features, item_modality_features
        )
        Z_users, Z_items, _ = model.cross_attention(H_U, H_I, H_UI_users, H_UI_items)
        combined_features = torch.cat([Z_users, Z_items], dim=0)
        z, mu, logvar = model.vgae.encode(combined_features, edge_index)

        # Contrastive losses (compute once per epoch; distribute across batches)
        contrastive_losses = model.compute_contrastive_losses(
            bipartite_edge_index=edge_index,
            item_modality_features=item_modality_features
        )
        loss_inter_epoch = contrastive_losses['L_inter']
        loss_struct_epoch = contrastive_losses['L_struct']

        # Cold-start loss (optional; compute once per epoch; distribute across batches)
        loss_cold_epoch = torch.tensor(0.0, device=device)
        if include_cold_start:
            # Simulate cold users from training interactions (stable and meaningful)
            cold_user_ids, _, _ = simulate_cold_start(
                train_users, train_items, n_users,
                keep_k=5, cold_ratio=0.2, seed=epoch
            )
            cold_user_ids_unique = np.unique(cold_user_ids)
            if len(cold_user_ids_unique) > 0:
                warm_user_ids = np.setdiff1d(np.unique(train_users), cold_user_ids_unique)
                if len(warm_user_ids) > 0:
                    # Limit warm pool for compute stability on CPU
                    if len(warm_user_ids) > 2048:
                        warm_user_ids = np.random.choice(warm_user_ids, size=2048, replace=False)

                    cold_embeds = H_U[torch.tensor(cold_user_ids_unique, device=device)]
                    warm_embeds = H_U[torch.tensor(warm_user_ids, device=device)]
                    cold_cluster_labels = torch.tensor(user_labels[cold_user_ids_unique], device=device)
                    warm_cluster_labels = torch.tensor(user_labels[warm_user_ids], device=device)

                    loss_cold_epoch = cold_start_contrastive_loss(
                        cold_embeds, warm_embeds,
                        cold_cluster_labels, warm_cluster_labels,
                        temperature
                    )
        
        # Mini-batch training (only BPR varies per batch; other losses are shared per epoch)
        optimizer.zero_grad()
        for start in range(0, len(bpr_users), batch_size):
            end = min(start + batch_size, len(bpr_users))
            
            b_users = torch.tensor(bpr_users[start:end], dtype=torch.long, device=device)
            b_pos_items = torch.tensor(bpr_pos_items[start:end], dtype=torch.long, device=device)
            b_neg_items = torch.tensor(bpr_neg_items[start:end], dtype=torch.long, device=device)
            
            # Decode using the epoch-level latent variables
            n_users_total = user_features.shape[0]
            pos_item_offset = b_pos_items + n_users_total
            neg_item_offset = b_neg_items + n_users_total
            pos_logits = model.vgae.decode_logits(z, b_users, pos_item_offset)
            neg_logits = model.vgae.decode_logits(z, b_users, neg_item_offset)
            
            # L_BPR: ranking loss
            loss_bpr = bpr_loss(pos_logits, neg_logits)
            
            # L_KL: VGAE regularization
            loss_kl = model.vgae.kl_divergence(mu, logvar)
            
            # Batch loss = L_BPR + λ₄·L_KL
            # Apply KL annealing (beta warmup)
            beta = lambda_4 * min(1.0, epoch / warmup_epochs)
            
            loss_inter = loss_inter_epoch
            loss_struct = loss_struct_epoch
            loss_cold = loss_cold_epoch

            # Combined total loss
            # Distribute epoch-level regularizers across batches to keep gradient magnitudes stable.
            reg = beta * loss_kl + lambda_1 * loss_inter + lambda_2 * loss_struct
            if include_cold_start:
                reg = reg + lambda_3 * loss_cold
            batch_loss = loss_bpr + reg / max(n_batches, 1)
            
            retain = end < len(bpr_users)
            batch_loss.backward(retain_graph=retain)
            
            epoch_loss_bpr += loss_bpr.item()
            epoch_loss_kl += (beta * loss_kl).item() / max(n_batches, 1)
            epoch_loss_inter += (lambda_1 * loss_inter).item() / max(n_batches, 1)
            epoch_loss_struct += (lambda_2 * loss_struct).item() / max(n_batches, 1)
            epoch_loss_cold += (lambda_3 * loss_cold).item() / max(n_batches, 1) if include_cold_start else 0.0

        # Single optimizer step per epoch (avoids in-place param updates while retaining graph)
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        
        # Step scheduler
        scheduler.step()
        
        # Record losses
        avg_bpr = epoch_loss_bpr / max(n_batches, 1)
        avg_kl = epoch_loss_kl / max(n_batches, 1)
        avg_inter = epoch_loss_inter / max(n_batches, 1)
        avg_struct = epoch_loss_struct / max(n_batches, 1)
        avg_cold = epoch_loss_cold / max(n_batches, 1)
        beta = lambda_4 * min(1.0, epoch / warmup_epochs)
        
        avg_total = avg_bpr + beta * avg_kl + lambda_1 * avg_inter + lambda_2 * avg_struct
        if include_cold_start:
            avg_total += lambda_3 * avg_cold
        
        train_losses.append(avg_total)
        loss_components_history['L_BPR'].append(avg_bpr)
        loss_components_history['L_inter'].append(avg_inter)
        loss_components_history['L_struct'].append(avg_struct)
        loss_components_history['L_KL'].append(avg_kl)
        loss_components_history['L_cold'].append(avg_cold)
        loss_components_history['L_total'].append(avg_total)
        
        epoch_time = time.time() - epoch_start
        
        # Checkpointing (fresh model only; no loading)
        if save_every and (epoch % save_every == 0):
            ckpt_path = os.path.join("results", f"checkpoint_{config.get('dataset','run')}_epoch{epoch}.pth")
            torch.save(model.state_dict(), ckpt_path)

        # Evaluation
        if epoch % eval_every == 0 or epoch == 1 or epoch == epochs:
            model.eval()
            
            with torch.no_grad():
                # Link prediction on validation set (adding negative edges!)
                val_pos_users = torch.tensor(user_idx[val_idx], dtype=torch.long, device=device)
                val_pos_items = torch.tensor(item_idx[val_idx], dtype=torch.long, device=device)
                
                # Sample negative edges for validation
                val_neg_users, _, val_neg_items = negative_sampling_bpr(
                    user_idx[val_idx], item_idx[val_idx], n_items, n_neg=1
                )
                val_neg_users = torch.tensor(val_neg_users, dtype=torch.long, device=device)
                val_neg_items = torch.tensor(val_neg_items, dtype=torch.long, device=device)
                
                val_users = torch.cat([val_pos_users, val_neg_users])
                val_items = torch.cat([val_pos_items, val_neg_items])
                val_labels = torch.cat([
                    torch.ones(len(val_idx), dtype=torch.float32, device=device),
                    torch.zeros(len(val_idx), dtype=torch.float32, device=device)
                ])
                
                val_logits, _, _, _ = model(
                    user_features, item_features, edge_index,
                    val_users, val_items,
                    user_modality_features, item_modality_features
                )
                
                lp_metrics = evaluate_link_prediction(val_logits, val_labels)
                
                # Recommendation evaluation
                eval_train_mask = train_mask.copy()
                if epoch != epochs:
                    # Quick eval for speed: sample 1000 users
                    rng = np.random.RandomState(42 + epoch)
                    candidate_users = np.unique(user_idx[val_idx])
                    if len(candidate_users) > 1000:
                        sample_users = rng.choice(candidate_users, size=1000, replace=False)
                    else:
                        sample_users = candidate_users
                    score_sub = model.get_all_scores(
                        user_features, item_features, edge_index,
                        user_modality_features, item_modality_features,
                        user_ids=sample_users
                    ).cpu().numpy()
                    # Build a small score_matrix-like view for subset evaluator
                    # We evaluate on the original user ids, so pass a full-sized matrix slice via mapping.
                    # Here we just place subset rows into a full matrix-like object by indexing inside evaluator.
                    # easiest: create a temporary full matrix for those users only in evaluator by direct access:
                    # (evaluate_model_subset expects score_matrix[u] indexing, so we provide a callable-like array)
                    # We'll instead build a dense (len(sample_users), n_items) and use a wrapper array.
                    # To keep it simple, evaluate_model_subset will index by u, so we need a full matrix.
                    # Create a lightweight full matrix with NaNs, but only fill sampled rows.
                    score_matrix = np.full((n_users, n_items), -np.inf, dtype=np.float32)
                    score_matrix[sample_users] = score_sub
                    rec_metrics = evaluate_model_subset(score_matrix, rating_matrix, eval_train_mask, sample_users, k=k)
                else:
                    # Full eval at final epoch
                    score_matrix_tensor = model.get_all_scores(
                        user_features, item_features, edge_index,
                        user_modality_features, item_modality_features
                    )
                    score_matrix = score_matrix_tensor.cpu().numpy()
                    rec_metrics = evaluate_model(score_matrix, rating_matrix, eval_train_mask, k=k)
                
                cold_metrics = {}
            
            for metric_name in epoch_metrics_history:
                if metric_name in rec_metrics:
                    epoch_metrics_history[metric_name].append(rec_metrics[metric_name])
            
            for metric_name in cold_start_metrics_history:
                if metric_name in cold_metrics:
                    cold_start_metrics_history[metric_name].append(cold_metrics[metric_name])
            
            # Track best model by validation NDCG@K (per ARCHITECTURE.md)
            val_ndcg = rec_metrics.get('NDCG@K', 0.0)
            if val_ndcg > best_val_ndcg + 1e-6:
                best_val_ndcg = val_ndcg
                bad_eval_count = 0
                best_model_state = {k_: v.cpu().clone() for k_, v in model.state_dict().items()}
                os.makedirs('results', exist_ok=True)
                torch.save(best_model_state, 'results/best_model.pth')
            else:
                bad_eval_count += 1
            
            loss_str = (f"L_BPR: {avg_bpr:.4f} | L₁: {loss_inter.item():.4f} | "
                       f"L₂: {loss_struct.item():.4f} | L_KL: {avg_kl:.4f}")
            if include_cold_start:
                loss_str += f" | L₃: {loss_cold.item():.4f}"
            
            metric_str = (f"P@{k}: {rec_metrics['Precision@K']:.4f} | R@{k}: {rec_metrics['Recall@K']:.4f} | "
                         f"NDCG@{k}: {rec_metrics['NDCG@K']:.4f} | F1@{k}: {rec_metrics['F1-Score@K']:.4f}")
            
            cold_str = ""
            
            print(f"Epoch {epoch:3d}/{epochs} | Total: {avg_total:.4f} | {loss_str} | "
                  f"Time: {epoch_time:.1f}s")
            print(f"  Metrics: {metric_str}{cold_str}")

            if bad_eval_count >= patience:
                print(f"[EARLY STOP] No val NDCG@{k} improvement for {patience} evals. Stopping.")
                break
        else:
            loss_str = (f"L_BPR: {avg_bpr:.4f} | L₁: {loss_inter.item():.4f} | "
                       f"L₂: {loss_struct.item():.4f} | L_KL: {avg_kl:.4f}")
            if include_cold_start:
                loss_str += f" | L₃: {loss_cold.item():.4f}"
            print(f"Epoch {epoch:3d}/{epochs} | Total: {avg_total:.4f} | {loss_str} | "
                  f"Time: {epoch_time:.1f}s")
        
        # Save latest checkpoint
        save_every = config.get('save_every', 10)
        if epoch % save_every == 0 or epoch == epochs:
            checkpoint = {
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_val_ndcg': best_val_ndcg,
                'best_model_state': best_model_state,
                'train_losses': train_losses,
                'loss_components_history': loss_components_history,
                'epoch_metrics_history': epoch_metrics_history,
                'cold_start_metrics_history': cold_start_metrics_history
            }
            os.makedirs('results', exist_ok=True)
            torch.save(checkpoint, 'results/latest_checkpoint.pth')
    
    # Load best model
    if best_model_state:
        model.load_state_dict({k_: v.to(device) for k_, v in best_model_state.items()})
    
    # Final evaluation on test set (warm users)
    print("\n" + "=" * 80)
    print("FINAL EVALUATION ON TEST SET")
    print("=" * 80)
    
    model.eval()
    with torch.no_grad():
        # Test link prediction (adding negative edges!)
        test_pos_users = torch.tensor(user_idx[test_idx], dtype=torch.long, device=device)
        test_pos_items = torch.tensor(item_idx[test_idx], dtype=torch.long, device=device)
        
        # Sample negative edges for testing
        test_neg_users, _, test_neg_items = negative_sampling_bpr(
            user_idx[test_idx], item_idx[test_idx], n_items, n_neg=1
        )
        test_neg_users = torch.tensor(test_neg_users, dtype=torch.long, device=device)
        test_neg_items = torch.tensor(test_neg_items, dtype=torch.long, device=device)
        
        test_users = torch.cat([test_pos_users, test_neg_users])
        test_items = torch.cat([test_pos_items, test_neg_items])
        test_labels = torch.cat([
            torch.ones(len(test_idx), dtype=torch.float32, device=device),
            torch.zeros(len(test_idx), dtype=torch.float32, device=device)
        ])
        
        test_logits, _, _, _ = model(
            user_features, item_features, edge_index,
            test_users, test_items,
            user_modality_features, item_modality_features
        )
        
        test_lp_metrics = evaluate_link_prediction(test_logits, test_labels)
        
        # Full recommendation evaluation on test (warm users only)
        print("[INFO] Computing test scores for all users...")
        score_matrix_tensor = model.get_all_scores(
            user_features, item_features, edge_index,
            user_modality_features, item_modality_features
        )
        score_matrix = score_matrix_tensor.cpu().numpy()
        
        # Test mask
        test_mask = np.zeros((n_users, n_items), dtype=bool)
        for idx in np.concatenate([train_idx, val_idx]):
            u, i = user_idx[idx], item_idx[idx]
            test_mask[u, i] = True
        
        final_metrics = evaluate_model(score_matrix, rating_matrix, test_mask, k=k)
        
        final_cold_metrics = {}
    
    print(f"\n{'Metric':<25} {'Value':<15}")
    print("-" * 40)
    for metric, value in final_metrics.items():
        print(f"{metric:<25} {value:<15.4f}")
    
    # Cold-start holdout evaluation (CHECK 5)
    if include_cold_start and 'cold_users_orig' in data:
        print("\n" + "=" * 80)
        print("COLD-START HOLDOUT EVALUATION (K=5 revealed, K=10 metrics)")
        print("=" * 80)

        cold_users_orig = data['cold_users_orig']
        cold_user_features = data['cold_user_features'].to(device)
        cold_user_modality = {k_: v.to(device) for k_, v in data['cold_user_modality_features'].items()}
        cold_known = data['cold_known_items']
        cold_gt = data['cold_gt_items']

        # Build augmented graph: warm train edges + cold revealed edges
        n_users_warm = n_users
        n_cold = cold_user_features.shape[0]
        n_users_all = n_users_warm + n_cold

        # Warm train edges are already in edge_index (with item offset n_users_warm)
        # Rebuild warm edges with new item offset n_users_all
        train_users = user_idx[train_idx]
        train_items = item_idx[train_idx]
        warm_edge_index_aug = torch.tensor(
            np.stack([
                np.concatenate([train_users, train_items + n_users_all]),
                np.concatenate([train_items + n_users_all, train_users])
            ]),
            dtype=torch.long,
            device=device
        )

        # Cold revealed edges
        cold_src = []
        cold_dst = []
        for j, u_orig in enumerate(cold_users_orig):
            known_items = cold_known.get(int(u_orig), np.array([], dtype=int))
            cold_uid = n_users_warm + j
            for it in known_items:
                cold_src.extend([cold_uid, n_users_all + int(it)])
                cold_dst.extend([n_users_all + int(it), cold_uid])
        cold_edge_index_aug = torch.tensor([cold_src, cold_dst], dtype=torch.long, device=device)
        edge_index_aug = torch.cat([warm_edge_index_aug, cold_edge_index_aug], dim=1)

        # --- CF embeddings over augmented graph (cold users have no ID embeddings) ---
        with torch.no_grad():
            # Warm users: ID emb + proj(feat); Cold users: proj(feat) only
            lightgcn = model.cf_module.lightgcn
            warm_id = lightgcn.user_embedding.weight
            cold_id = torch.zeros((n_cold, warm_id.shape[1]), device=device)
            user_init = torch.cat([warm_id, cold_id], dim=0) + model.cf_module.lightgcn.user_feat_proj(
                torch.cat([user_features, cold_user_features], dim=0)
            )
            item_init = lightgcn.item_embedding.weight + model.cf_module.lightgcn.item_feat_proj(item_features)
            all_init = torch.cat([user_init, item_init], dim=0)
            # propagate using LightGCN's augmented forward
            all_emb = lightgcn.forward_with_augmented_graph(edge_index_aug, x=all_init, n_nodes=n_users_all + n_items)
            H_U_all = all_emb[:n_users_all]
            H_I_all = all_emb[n_users_all:]
    
            # --- CBF embeddings for warm+cold users using cluster assignment ---
            cbf = model.cbf_module
            user_labels_warm = cbf.user_labels
            user_labels_cold = cbf.predict_user_clusters(cold_user_features)
            user_labels_all = np.concatenate([user_labels_warm, user_labels_cold])
            item_labels = cbf.item_labels
            # forward with label override
            _, H_UI_users_all, H_UI_items = cbf(
                torch.cat([user_features, cold_user_features], dim=0),
                item_features,
                {k_: torch.cat([user_modality_features[k_], cold_user_modality[k_]], dim=0) for k_ in user_modality_features},
                item_modality_features,
                user_labels_override=user_labels_all,
                item_labels_override=item_labels
            )
    
            # --- Cross-attention + VGAE encode on augmented graph ---
            Z_users_all, Z_items, _ = model.cross_attention(H_U_all, H_I_all, H_UI_users_all, H_UI_items)
            combined = torch.cat([Z_users_all, Z_items], dim=0)
            z, _, _ = model.vgae.encode(combined, edge_index_aug)
            z_users = z[:n_users_all]
            z_items = z[n_users_all:]
            scores_cold = torch.sigmoid(torch.mm(z_users[n_users_warm:], z_items.t())).detach().cpu().numpy()

        # Compute cold metrics
        from evaluate import hit_at_k, ndcg_at_k, recall_at_k
        hit_list, ndcg_list, recall_list = [], [], []
        for j, u_orig in enumerate(cold_users_orig):
            known_items = set(map(int, cold_known.get(int(u_orig), np.array([], dtype=int)).tolist()))
            gt_items = set(map(int, cold_gt.get(int(u_orig), np.array([], dtype=int)).tolist()))
            if len(gt_items) == 0:
                continue
            s = scores_cold[j].copy()
            for it in known_items:
                s[it] = -np.inf
            topk = np.argsort(-s)[:k]
            gt_list = list(gt_items)
            hit_list.append(hit_at_k(topk, gt_list, k))
            ndcg_list.append(ndcg_at_k(topk, gt_list, k))
            recall_list.append(recall_at_k(topk, gt_list, k))

        final_cold_metrics = {
            "ColdStart-Hit@K": float(np.mean(hit_list)) if hit_list else 0.0,
            "ColdStart-NDCG@K": float(np.mean(ndcg_list)) if ndcg_list else 0.0,
            "ColdStart-Recall@K": float(np.mean(recall_list)) if recall_list else 0.0,
        }
        for metric, value in final_cold_metrics.items():
            print(f"{metric:<25} {value:<15.4f}")
    
    print(f"\nLink Prediction Metrics:")
    for metric, value in test_lp_metrics.items():
        print(f"  {metric}: {value:.4f}")
    
    # Generate visualizations
    print("\n[INFO] Generating visualizations...")
    plot_training_loss(train_losses, save_path='results/training_loss_ml1m.png',
                       title='Training Loss - MM-CLightRec on MovieLens 1M')
    plot_metrics_bar(final_metrics, save_path='results/metrics_ml1m.png',
                     title='MM-CLightRec Performance on MovieLens 1M')
    
    if epoch_metrics_history['Precision@K']:
        plot_metrics_over_epochs(epoch_metrics_history, save_path='results/metrics_over_epochs_ml1m.png',
                                  title='Metrics Over Epochs - MM-CLightRec')
    
    plot_link_prediction_metrics(test_lp_metrics, save_path='results/link_prediction_ml1m.png')
    
    if loss_components_history['L_BPR']:
        plot_loss_components(loss_components_history, save_path='results/loss_components_ml1m.png',
                            include_cold_start=include_cold_start)
    
    results = {
        'train_losses': train_losses,
        'loss_components': loss_components_history,
        'final_metrics': final_metrics,
        'cold_start_metrics': final_cold_metrics,
        'lp_metrics': test_lp_metrics,
        'epoch_metrics': epoch_metrics_history,
        'cold_start_epoch_metrics': cold_start_metrics_history,
        'config': config,
    }
    
    return model, results
