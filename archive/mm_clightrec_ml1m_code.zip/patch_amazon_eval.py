import json, os

notebook_path = "MM_CLightRec_AmazonBaby_v3_EarlyFusion.ipynb"

# The literal source code for the new cell, customized for Amazon Baby notebook
# Notice that Amazon Baby has 'DEVICE' instead of 'device', and variables like 'data' are global
NEW_CELL_SRC = r"""
# ════════════════════════════════════════════════════════════════════════
# SAMPLED NEGATIVE EVALUATION (Matches Base Paper Protocol)
# 1 positive + 99 negatives per user (no retraining needed)
# ════════════════════════════════════════════════════════════════════════

print('\n' + '='*70)
print('  RUNNING SAMPLED EVALUATION (1 Pos + 99 Neg) on Best Saved Model')
print('='*70)

N_NEGATIVE = 99
K = 10
SEED = 42

# 1. Load best model weights
best_ckpt = f"{CONFIG['checkpoint_dir']}/epoch_{epoch+1}_v3.pt"
import glob
checkpoints = glob.glob(f"{CONFIG['checkpoint_dir']}/epoch_*_v3.pt")
if checkpoints:
    # Get the latest checkpoint
    checkpoints.sort(key=os.path.getmtime)
    best_ckpt = checkpoints[-1]
    state = torch.load(best_ckpt, map_location=DEVICE)
    if 'model_state_dict' in state:
        model.load_state_dict(state['model_state_dict'])
    else:
        model.load_state_dict(state)
    print(f"[INFO] Loaded model from {best_ckpt} ✅")
else:
    print("[WARNING] No checkpoints found, running on whatever is currently in VRAM.")

model.eval()

# 2. Compute full score matrix efficiently
print("[INFO] Computing full (user x item) score matrix...")
with torch.no_grad():
    mod_gpu = {mk: mv.to(DEVICE) for mk, mv in data['modality_features'].items()}
    uf = data['user_features'].to(DEVICE)
    if_ = data['item_features'].to(DEVICE)
    
    # Forward pass to get embeddings
    outputs = model(data['edge_index'].to(DEVICE), mod_gpu,
                    user_features=uf, item_features=if_)
    
    H_U = outputs['H_U']
    H_I = outputs['H_I']
    
    # Full dot product matrix
    scores = torch.matmul(H_U, H_I.T).cpu().numpy()

print(f"[INFO] Score matrix: {scores.shape} ✅")

# 3. Sampled Evaluation Engine
def compute_ndcg_sampled(ranked_list, pos_item, k):
    for rank, item in enumerate(ranked_list[:k]):
        if item == pos_item:
            return 1.0 / np.log2(rank + 2)
    return 0.0

rng = np.random.RandomState(SEED)
prec_list, rec_list, ndcg_list, f1_list = [], [], [], []

n_items = data['n_items']
for u, pos_items in data['test_user_items'].items():
    if not pos_items: continue
    
    pos_item = pos_items[0] # Take first positive
    
    # All items user has ever seen
    seen = set(data['train_user_items'].get(u, [])) | set(pos_items)
    
    # Sample 99 unknown items
    unseen = np.array([i for i in range(n_items) if i not in seen])
    negs = rng.choice(unseen, size=min(n_neg, len(unseen)), replace=False) if len(unseen) > N_NEGATIVE else unseen
    
    candidates = np.concatenate([[pos_item], negs])
    
    # Score candidate pool
    s = scores[u][candidates]
    order = np.argsort(-s)
    ranked = candidates[order]
    
    # Metrics
    hits = int(pos_item in ranked[:K])
    p = hits / K
    r = float(hits)  # Recall is hits/1 since only 1 pos item
    nd = compute_ndcg_sampled(ranked, pos_item, K)
    f = 2*p*r/(p+r) if (p+r) > 0 else 0.0
    
    prec_list.append(p)
    rec_list.append(r)
    ndcg_list.append(nd)
    f1_list.append(f)

print('\n' + '='*70)
print(f'          SAMPLED EVALUATION RESULTS (K={K})')
print('='*70)
print(f'  Precision@{K}  : {np.mean(prec_list):.4f}')
print(f'  Recall@{K}     : {np.mean(rec_list):.4f}')
print(f'  NDCG@{K}       : {np.mean(ndcg_list):.4f}')
print(f'  F1-Score@{K}   : {np.mean(f1_list):.4f}')
print('='*70)
print('  (These numbers are directly comparable to the MGRS-HFA paper)')
print('='*70)
"""

def patch_amazon_notebook():
    if not os.path.exists(notebook_path):
        print(f"File not found: {notebook_path}")
        return
        
    with open(notebook_path, 'r', encoding='utf-8') as f:
        nb = json.load(f)
        
    # Check if we already added it
    for cell in nb['cells']:
        if "SAMPLED NEGATIVE EVALUATION (Matches Base Paper Protocol)" in "".join(cell.get('source', [])):
            print("Cell already exists!")
            return
            
    # Add to the end
    lines = NEW_CELL_SRC.strip().split('\n')
    source = [line + '\n' for line in lines[:-1]] + [lines[-1]] if lines else []
    
    new_cell = {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": source
    }
    
    nb['cells'].append(new_cell)
    
    with open(notebook_path, 'w', encoding='utf-8') as f:
        json.dump(nb, f, indent=1, ensure_ascii=False)
        
    print(f"Successfully appended Sampled Evaluation cell to {notebook_path}")

if __name__ == "__main__":
    patch_amazon_notebook()
